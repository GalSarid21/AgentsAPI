﻿namespace AgentsDM
{
    public class ClosestMissionResponse : BaseResponse
    {
        public Mission Mission { get; set; }
    }
}
