﻿namespace AgentsDM
{
    public class AddMissionRequest
    {
        public Mission mission { get; set; }
    }
}
