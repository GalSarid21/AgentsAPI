﻿namespace AgentsUtils.Consts
{
    public struct CalculationConsts
    {
        public const int EARTH_RADIUS_IN_KM = 6371;
    }
}
